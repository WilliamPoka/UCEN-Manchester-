#the final countdown doo doo doo doo doo doo da da doo doo doo

def print_and_save_results(num1, num2, sum1, difference1, product1, quotient1):
    # Display results to user, hee hee harr harr
    print(f"Your sum is: {sum1}. The Difference is: {difference1}. The Product is: {product1}. The quotient is: {quotient1}")
    
    # Save results to file because modular code thingy magijjes
    with open("calculations.txt", "a") as file:
        file.write(f"The sum of {num1} and {num2} is {sum1}\n")
        file.write(f"The difference between {num1} and {num2} is {difference1}\n")
        file.write(f"The product of {num1} and {num2} is {product1}\n")
        file.write(f"The quotient of {num1} and {num2} is {quotient1}\n")
