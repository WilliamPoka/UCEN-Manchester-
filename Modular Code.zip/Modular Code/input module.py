# input KAKKAKAKAK

def get_input():
    num1 = float(input("Pick any number: "))
    num2 = float(input("Pick your second number: "))
    return num1, num2
