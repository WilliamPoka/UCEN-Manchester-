# The quick calculations! and that

def calculate(num1, num2):
    sum1 = num1 + num2
    difference1 = num1 - num2
    product1 = num1 * num2
    quotient1 = num1 / num2
    return sum1, difference1, product1, quotient1
