import the_maths 
import input_module
import the results

num1, num2 = get_input()
sum1, difference1, product1, quotient1 = calculate(num1, num2)

def print_and_save_results(num1, num2, sum1, difference1, product1, quotient1)
